package com.shop.core;

import java.io.Serializable;
import java.time.LocalDate;

/*
 * product id (int : PK) , name (string) , description , quantity , price , category (enum : BREAD, BISCUITS,OIL,GRAIN,SPICES,FRUITS....)
 * ,manufactureDate

 */
public class Product implements Serializable{
	private static final long serialVersionUID=1;
	
/**
	 * 
	 */
	//private static final long serialVersionUID = 6295348737730222500L;
/**
	 * 
	 */
//	private static final long serialVersionUID = 7247332787111109514L;
	//state : data
	private int productId;
	private String name;
	private String desc;
	private int quantity;
	private double price;
	private Category productCategory;
	private transient LocalDate manufactureDate;
	public Product(int productId, String name, String desc, 
			int quantity, double price, Category productCategory,
			LocalDate manufactureDate) {
		super();
		this.productId = productId;
		this.name = name;
		this.desc = desc;
		this.quantity = quantity;
		this.price = price;
		this.productCategory = productCategory;
		this.manufactureDate = manufactureDate;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", desc=" + desc + ", quantity=" + quantity
				+ ", price=" + price + ", productCategory=" + productCategory + ", manufactureDate=" + manufactureDate
				+ "]";
	}
	public int getProductId() {
		return productId;
	}
	public String getName() {
		return name;
	}
	public String getDesc() {
		return desc;
	}
	public int getQuantity() {
		return quantity;
	}
	public double getPrice() {
		return price;
	}
	public Category getProductCategory() {
		return productCategory;
	}
	public LocalDate getManufactureDate() {
		return manufactureDate;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
